package es.david.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import es.david.conexion.DBUtils;
import es.david.dao.*;
import es.david.model.DatosNoCorrectosException;
import es.david.model.Empleado;

public class EmpleadoDao {
	private Connection connection;
	private PreparedStatement statement;
	private boolean estadoOperacion;

// guardar empleado
	public boolean guardar(Empleado empleado) throws SQLException {
		String sql = null;
		estadoOperacion = false;
		connection = obtenerConexion();

		try {
			connection.setAutoCommit(false);
			sql = "INSERT INTO empleados (dni, nombre, sexo, categoria, anyos) VALUES(?,?,?,?,?)";
			statement = connection.prepareStatement(sql);

			statement.setString(1, empleado.getDni());
			statement.setString(2, empleado.getNombre());
			statement.setString(3, empleado.getSexo());
			statement.setInt(4, empleado.getCategoria());
			statement.setInt(5, empleado.getAnyos());

			estadoOperacion = statement.executeUpdate() > 0;

			connection.commit();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			connection.rollback();
			e.printStackTrace();
		}

		return estadoOperacion;
	}

// editar empleado
	public boolean editar(Empleado empleado) throws SQLException {
		String sql = null;
		estadoOperacion = false;
		connection = obtenerConexion();
		try {
			connection.setAutoCommit(false);
			sql = "UPDATE empleados SET nombre=?, sexo=?, categoria=?, anyos=? WHERE dni=?";
			statement = connection.prepareStatement(sql);

			statement.setString(1, empleado.getNombre());
			statement.setString(2, empleado.getSexo());
			statement.setInt(3, empleado.getCategoria());
			statement.setInt(4, empleado.getAnyos());
			statement.setString(5, empleado.getDni()); // Establece el valor para el quinto parámetro (dni)

			estadoOperacion = statement.executeUpdate() > 0;
			connection.commit();
			statement.close();
			connection.close();

		} catch (SQLException e) {
			connection.rollback();
			e.printStackTrace();
		}

		return estadoOperacion;
	}

// eliminar empleado
	public boolean eliminar(String dniEmpleado) throws SQLException {
		String sql = null;
		estadoOperacion = false;
		connection = obtenerConexion();
		try {
			connection.setAutoCommit(false);
			sql = "DELETE FROM empleados WHERE dni=?";
			statement = connection.prepareStatement(sql);
			statement.setString(1, dniEmpleado);

			estadoOperacion = statement.executeUpdate() > 0;
			connection.commit();
			statement.close();
			connection.close();

		} catch (SQLException e) {
			connection.rollback();
			e.printStackTrace();
		}

		return estadoOperacion;
	}

// obtener lista de empleados
	public List<Empleado> obtenerEmpleados() throws SQLException, DatosNoCorrectosException {
		ResultSet resultSet = null;
		List<Empleado> listaEmpleados = new ArrayList<>();

		String sql = null;
		estadoOperacion = false;
		connection = obtenerConexion();

		try {
			sql = "SELECT * FROM empleados";
			statement = connection.prepareStatement(sql);
			resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {

				Empleado empleado = new Empleado();

				empleado.setDni(resultSet.getString(1));
				empleado.setNombre(resultSet.getString(2));
				empleado.setSexo(resultSet.getString(3));
				empleado.setCategoria(resultSet.getInt(4));
				empleado.setAnyos(resultSet.getInt(5));
				listaEmpleados.add(empleado);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaEmpleados;
	}

// obtener empleado por dni
	public Empleado obtenerEmpleado(String dniEmpleado) throws SQLException, DatosNoCorrectosException {
		ResultSet resultSet = null;
		Empleado empleado = null;

		String sql = null;
		estadoOperacion = false;
		connection = obtenerConexion();

		try {
			sql = "SELECT * FROM empleados WHERE dni =?";
			statement = connection.prepareStatement(sql);
			statement.setString(1, dniEmpleado);

			resultSet = statement.executeQuery();

			if (resultSet.next()) {
				empleado = new Empleado();
				empleado.setDni(resultSet.getString(1));
				empleado.setNombre(resultSet.getString(2));
				empleado.setSexo(resultSet.getString(3));
				empleado.setCategoria(resultSet.getInt(4));
				empleado.setAnyos(resultSet.getInt(5));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return empleado;
	}

// obtener conexion pool
	private Connection obtenerConexion() throws SQLException {
		return DBUtils.getConnection();
	}

}