package es.david.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.david.dao.*;
import es.david.model.*;

/**
 * Servlet implementation class ProductoController
 */
@WebServlet(description = "administra peticiones para la tabla empleados", urlPatterns = { "/empleados" })
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		// guardamos la opcion para que entre en los diferentes if
		String opcion = request.getParameter("opcion");

		// si pulsamos crear nos dirige al jsp de crear
		if (opcion.equals("crear")) {
			System.out.println("Usted ha presionado la opcion crear");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/crear.jsp");
			requestDispatcher.forward(request, response);

			// si pulsamos crear nos dirige al jsp de listar
		} else if (opcion.equals("listar")) {

			EmpleadoDao empleadoDao = new EmpleadoDao();
			List<Empleado> lista = new ArrayList<>();
			try {
				try {
					lista = empleadoDao.obtenerEmpleados();
				} catch (DatosNoCorrectosException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for (Empleado empleado : lista) {
					System.out.println(empleado.getNombre());
				}

				request.setAttribute("lista", lista);
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/listar.jsp");
				requestDispatcher.forward(request, response);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Usted ha presionado la opcion listar");

			// si pulsamos crear nos dirige al jsp de editar
		} else if (opcion.equals("editar")) {

			String dni = (request.getParameter("id"));
			System.out.println("Editar dni: " + dni);
			EmpleadoDao empleadoDao = new EmpleadoDao();
			Empleado empleado = new Empleado();

			try {
				try {
					empleado = empleadoDao.obtenerEmpleado(dni);
				} catch (DatosNoCorrectosException e) {
					e.printStackTrace();
				}
				System.out.println(empleado);
				request.setAttribute("empleado", empleado);
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/editar.jsp");
				requestDispatcher.forward(request, response);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// elimina un empleado segun su id
		} else if (opcion.equals("eliminar")) {
			EmpleadoDao empleadoDao = new EmpleadoDao();
			String dni = (request.getParameter("id"));
			try {
				empleadoDao.eliminar(dni);
				System.out.println("Registro eliminado satisfactoriamente...");
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/index.jsp");
				requestDispatcher.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (opcion.equals("buscarPorDni")) {
			System.out.println("Usted ha presionado la opcion buscarPorDni");

			// Redirigir a la página JSP para introducir el DNI
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/views/buscar.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String opcion = request.getParameter("opcion");

		// entre por crear y guarda el nuevo empleado
		if (opcion.equals("guardar")) {
			EmpleadoDao empleadoDao = new EmpleadoDao();
			Empleado empleado = new Empleado();
			empleado.setDni(request.getParameter("dni"));
			empleado.setNombre(request.getParameter("nombre"));
			empleado.setSexo(request.getParameter("sexo"));
			try {
				empleado.setCategoria(Integer.parseInt(request.getParameter("categoria")));
			} catch (NumberFormatException | DatosNoCorrectosException e) {
				e.printStackTrace();
			}
			empleado.setAnyos(Integer.parseInt(request.getParameter("anyos")));
			try {
				empleadoDao.guardar(empleado);
				System.out.println("Registro guardado satisfactoriamente...");
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/index.jsp");
				requestDispatcher.forward(request, response);

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		// modificamos valores del empleado sin tocar su dni
		else if (opcion.equals("editar")) {
			Empleado empleado = new Empleado();
			EmpleadoDao empleadoDao = new EmpleadoDao();

			empleado.setDni(request.getParameter("dni"));
			empleado.setNombre(request.getParameter("nombre"));
			empleado.setSexo(request.getParameter("sexo"));
			try {
				empleado.setCategoria(Integer.parseInt(request.getParameter("categoria")));
			} catch (DatosNoCorrectosException e) {
				e.printStackTrace();
			}
			empleado.setAnyos(Integer.parseInt(request.getParameter("anyos")));
			try {
				empleadoDao.editar(empleado);

				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/index.jsp");
				requestDispatcher.forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		// buscamos un empleado mediante su dni
		else if (opcion.equals("buscar")) {
			System.out.println("usted ha presionado buscar en POST");
			EmpleadoDao empleadoDao = new EmpleadoDao();
			String dni = request.getParameter("dni");
			Nomina nomina = new Nomina();

			try {
				// Realiza la búsqueda del empleado por DNI en la base de datos
				Empleado empleado = empleadoDao.obtenerEmpleado(dni);

				if (empleado != null) {
					// Calcula el salario del empleado
					double salario = nomina.sueldo(empleado);

					// Establece los atributos en el request
					request.setAttribute("dni", empleado.getDni());
					request.setAttribute("nombre", empleado.getNombre());
					request.setAttribute("sexo", empleado.getSexo());
					request.setAttribute("categoria", empleado.getCategoria());
					request.setAttribute("anyos", empleado.getAnyos());
					request.setAttribute("salario", salario);

					// Redirige a la página JSP para mostrar los datos del empleado y su salario
					request.getRequestDispatcher("views/salario.jsp").forward(request, response);
				} else {
					// El empleado no se encontró en la base de datos, establece un mensaje de error
					request.setAttribute("error", "No se encontró el empleado con el DNI: " + dni);

					// Redirige a una página de error o a la misma página de búsqueda con el mensaje
					// de error
					request.getRequestDispatcher("views/error.jsp").forward(request, response);
				}
			} catch (DatosNoCorrectosException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// doGet(request, response);
	}

}